package biz;

import db.dao.DAO;
import junit.framework.TestCase;
import model.*;
import model.exceptions.UserUnnkownOrBadPasswordException;
import model.operations.*;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.sql.SQLException;

import static org.junit.Assert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class AuthenticationManagerTest extends TestCase {
    @Mock
    DAO dao;

    @InjectMocks
    @Spy
    BankHistory bankHistory;

    @InjectMocks
    @Spy
    AuthenticationManager authenticationManager;

    @Test
    public void testLogIn_success() throws SQLException, UserUnnkownOrBadPasswordException {
        // given
        String username = "patrykordon";
        String passwordText = "supersecret";
        Password password = new Password();
        password.setPasswd(AuthenticationManager.hashPassword(passwordText.toCharArray()));
        User user = new User();
        user.setId(123);
        user.setName("Patryk");
        given(dao.findUserByName(username)).willReturn(user);
        given(dao.findPasswordForUser(user)).willReturn(password);

        // when
        User loggedUser = authenticationManager.logIn(username, passwordText.toCharArray());

        // then
        assertEquals(loggedUser, user);
        verify(bankHistory, never()).logLoginFailure(any(), any());
    }

    @Test
    // BUG: "Bad password" gdy zła jest nazwa użytkownika
    public void testLogIn_badUsername() throws SQLException {
        // given
        String username = "patrykordon";
        String passwordText = "supersecret";
        given(dao.findUserByName(username)).willReturn(null);

        // when
        Exception e = Assert.assertThrows(UserUnnkownOrBadPasswordException.class, () -> authenticationManager.logIn(username, passwordText.toCharArray()));

        // then
        assertEquals("Bad Password", e.getMessage());
        verify(bankHistory, atLeastOnce()).logLoginFailure(eq(null), eq("Zła nazwa użytkownika " + username));
    }

    @Test
    public void testLogIn_sqlError() throws SQLException, UserUnnkownOrBadPasswordException {
        // given
        String username = "patrykordon";
        String passwordText = "supersecret";
        given(dao.findUserByName(username)).willThrow(SQLException.class);

        // when then
        Assert.assertThrows(SQLException.class, () -> authenticationManager.logIn(username, passwordText.toCharArray()));
    }

    @Test
    public void testLogIn_badPassword() throws SQLException, UserUnnkownOrBadPasswordException {
        // given
        String username = "patrykordon";
        String passwordText = "supersecret";
        Password password = new Password();
        password.setPasswd(AuthenticationManager.hashPassword("dfd".toCharArray()));
        User user = new User();
        user.setId(123);
        user.setName("Patryk");
        given(dao.findUserByName(username)).willReturn(user);
        given(dao.findPasswordForUser(user)).willReturn(password);

        // when
        Exception e = Assert.assertThrows(UserUnnkownOrBadPasswordException.class, () -> authenticationManager.logIn(username, passwordText.toCharArray()));

        // then
        assertEquals("Bad Password", e.getMessage());
        verify(bankHistory, atLeastOnce()).logLoginFailure(eq(user), eq("Bad Password"));
    }

    @Test()
    // BUG: logOut nigdy nie zwraca false
    public void testLogOut_success() throws SQLException {
        // given
        User user = new User();

        // when
        boolean status = authenticationManager.logOut(user);

        // then
        assertTrue(status);
        verify(dao, atLeastOnce()).logOperation(isA(LogOut.class), anyBoolean());
    }

    @Test(expected = SQLException.class)
    public void testLogOut_sqlError() throws SQLException {
        // given
        User user = new User();
        Mockito.doThrow(new SQLException()).when(dao).logOperation(any(LogOut.class), anyBoolean());

        // when
        authenticationManager.logOut(user);
    }

    @Test
    // Błąd jeżeli password == null
    public void testHashPassword_emptyString() {
        // given
        String passToHash = "";

        // when
        String result = AuthenticationManager.hashPassword(passToHash.toCharArray());

        // then
        assertNotNull(result);
    }

    @Test
    public void testCanInvokeOperation_admin() {
        // given
        Role role = new Role();
        role.setName("Admin");
        User admin = new User();
        admin.setRole(role);
        Operation operation = mock(Withdraw.class);

        // when
        boolean result = authenticationManager.canInvokeOperation(operation, admin);

        // then
        assertTrue(result);
        verify(operation, never()).getType();
    }

    @Test
    // BUG: Błąd przy braku role
    public void testCanInvokeOperation_paymentIn() {
        // given
        Role role = new Role();
        role.setName("User");
        User user = new User();
        user.setRole(role);
        Operation operation = mock(Withdraw.class);
        given(operation.getType()).willReturn(OperationType.PAYMENT_IN);

        // when
        boolean result = authenticationManager.canInvokeOperation(operation, user);

        // then
        assertTrue(result);
        verify(operation, atMostOnce()).getType();
    }

    @Test
    public void testCanInvokeOperation_withdraw_sameUser() {
        // given
        Role role = new Role();
        role.setName("User");
        User user = new User();
        user.setId(123);
        user.setRole(role);
        Operation operation = mock(Withdraw.class);
        given(operation.getType()).willReturn(OperationType.WITHDRAW);
        given(operation.getUser()).willReturn(user);

        // when
        boolean result = authenticationManager.canInvokeOperation(operation, user);

        // then
        assertTrue(result);
        verify(operation, times(2)).getType();
    }

    @Test
    public void testCanInvokeOperation_withdraw_differentUser() {
        // given
        Role role = new Role();
        role.setName("User");
        User user = new User();
        user.setId(123);
        user.setRole(role);
        Operation operation = mock(Withdraw.class);
        given(operation.getType()).willReturn(OperationType.WITHDRAW);
        User user2 = new User();
        user2.setId(124);
        given(operation.getUser()).willReturn(user2);

        // when
        boolean result = authenticationManager.canInvokeOperation(operation, user);

        // then
        assertFalse(result);
        verify(operation, times(2)).getType();
    }

    @Test
    // BUG: Inne operacje niż payment in, withdraw może tylko admin?
    public void testCanInvokeOperation_differentOperation() {
        // given
        Role role = new Role();
        role.setName("User");
        User user = new User();
        user.setId(123);
        user.setRole(role);
        Operation operation = mock(Withdraw.class);
        given(operation.getType()).willReturn(OperationType.INTEREST);

        // when
        boolean result = authenticationManager.canInvokeOperation(operation, user);

        // then
        assertFalse(result);
        verify(operation, times(2)).getType();
    }
}