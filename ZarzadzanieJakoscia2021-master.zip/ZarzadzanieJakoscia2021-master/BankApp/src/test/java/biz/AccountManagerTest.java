package biz;

import db.dao.DAO;
import junit.framework.TestCase;
import model.Account;
import model.Role;
import model.User;
import model.exceptions.OperationIsNotAllowedException;
import model.exceptions.UserUnnkownOrBadPasswordException;
import model.operations.OperationType;
import model.operations.PaymentIn;
import model.operations.Withdraw;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.sql.SQLException;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class AccountManagerTest extends TestCase {
    @Mock
    DAO dao;

    @InjectMocks
    @Spy
    BankHistory bankHistory;

    @InjectMocks
    @Spy
    AuthenticationManager authenticationManager;

    @InjectMocks
    @Spy
    InterestOperator interestOperator;

    @InjectMocks
    @Spy
    AccountManager accountManager;

    @Test
    // BUG: Wartość zmiennej success zostanie nadpisana i zwórcony będzie tylko stan operacji :31
    public void testPaymentIn_correctAmount() throws SQLException {
        // given
        double initialAmount = 123.45;
        double amountIn = 1000.56;
        User user = new User();
        Account account = new Account();
        account.setAmmount(initialAmount);
        account.setOwner(user);
        String description = "My first payment in";
        given(dao.findAccountById(account.getId())).willReturn(account);
        given(dao.updateAccountState(account)).willReturn(true);

        // when
        boolean result = accountManager.paymentIn(user, amountIn, description, account.getId());

        // then
        assertEquals(account.getAmmount(), initialAmount + amountIn);
        assertTrue(result);
        verify(bankHistory).logOperation(isA(PaymentIn.class), eq(true));
    }

    @Test
    public void testPaymentIn_nullAccount() throws SQLException {
        // given
        int accountId = 123;
        double initialAmount = 123.45;
        double amountIn = 1000.56;
        User user = new User();
        given(dao.findAccountById(accountId)).willReturn(null);

        // when
        boolean result = accountManager.paymentIn(user, amountIn, "", accountId);

        // then
        assertFalse(result);
        verify(bankHistory, never()).logOperation(isA(PaymentIn.class), eq(true));
    }

    @Test
    // BUG: Możliwa wpłata ujmenej kwoty, jeżeli dao zwróci false kwota przypisana do account pozostaje błędna
    public void testPaymentIn_negativeAmount() throws SQLException {
        // given
        double initialAmount = 123.45;
        double amountIn = -323.56;
        User user = new User();
        Account account = new Account();
        account.setAmmount(initialAmount);
        String description = "My first payment in";
        given(dao.findAccountById(account.getId())).willReturn(account);
        given(dao.updateAccountState(account)).willReturn(true);

        // when
        boolean result = accountManager.paymentIn(user, amountIn, description, account.getId());

        // then
        assertEquals(account.getAmmount(), initialAmount + amountIn);
        assertTrue(result);
        verify(bankHistory).logOperation(isA(PaymentIn.class), eq(true));
    }

    @Test
    public void testPaymentIn_sqlError() throws SQLException {
        // given
        double initialAmount = 123.45;
        double amountIn = 123.45;
        User user = new User();
        Account account = new Account();
        account.setAmmount(initialAmount);
        String description = "My first payment in";
        given(dao.findAccountById(account.getId())).willThrow(SQLException.class);

        // when then
        Assert.assertThrows(SQLException.class, () -> accountManager.paymentIn(user, amountIn, description, account.getId()));
    }

    @Test
    // BUG: W przypadku gdy operacja zwróci false :45, wtedy zmienna zostanie nadpisana przez dao i zwórci true
    public void testPaymentOut_success() throws OperationIsNotAllowedException, SQLException {
        // given
        double initialAmount = 1234.56;
        double amountOut = 234.56;
        double expectedAmount = 1000.00;
        User user = new User();
        Role role = new Role();
        role.setName("User");
        user.setRole(role);
        Account account = new Account();
        account.setAmmount(initialAmount);
        account.setOwner(user);
        given(dao.findAccountById(account.getId())).willReturn(account);
        given(dao.updateAccountState(account)).willReturn(true);

        // when
        boolean result = accountManager.paymentOut(user, amountOut, "", account.getId());

        // then
        verify(authenticationManager).canInvokeOperation(isA(Withdraw.class), eq(user));
        verify(bankHistory).logOperation(isA(Withdraw.class), eq(true));
        assertEquals(account.getAmmount(), expectedAmount);
        assertTrue(result);
    }

    @Test
    // BUG: Użytkownik nie powienien móc wykonać operacji, jeżeli nie jest właścicielem
    // Do operation jest przekazywany ten sam user, co 2 parametr funkcji ==> nie ma sensu sprawdzanie
    public void testPaymentOut_unauthorized() throws OperationIsNotAllowedException, SQLException {
        // given
        double initialAmount = 1234.56;
        double amountOut = 234.56;
        double expectedAmount = 1234.56;
        User user = new User();
        Role role = new Role();
        role.setName("User");
        user.setRole(role);
        Account account = new Account();
        account.setAmmount(initialAmount);
        account.setOwner(new User());
        given(dao.findAccountById(account.getId())).willReturn(account);
        given(dao.updateAccountState(account)).willReturn(true);

        // when
        boolean result = accountManager.paymentOut(user, amountOut, "", account.getId());

        System.out.println(result);
        // then
        verify(authenticationManager).canInvokeOperation(isA(Withdraw.class), eq(user));
        assertEquals(initialAmount, account.getAmmount());
        assertFalse(result);
    }

    @Test
    public void testPaymentOut_invokeFailed() throws OperationIsNotAllowedException, SQLException {
        // given
        double initialAmount = 1234.56;
        double amountOut = 234.56;
        double expectedAmount = 1000.00;
        User user = new User();
        Role role = new Role();
        role.setName("User");
        user.setRole(role);
        Account account = new Account();
        account.setAmmount(initialAmount);
        account.setOwner(user);
        given(dao.findAccountById(account.getId())).willReturn(account);
        doReturn(false).when(authenticationManager).canInvokeOperation(isA(Withdraw.class), eq(user));
        doNothing().when(bankHistory).logUnauthorizedOperation(isA(Withdraw.class), anyBoolean());

        // when then
        Exception e = Assert.assertThrows(OperationIsNotAllowedException.class, () -> accountManager.paymentOut(user, amountOut, "", account.getId()));

        assertEquals("Unauthorized operation", e.getMessage());
        verify(authenticationManager).canInvokeOperation(isA(Withdraw.class), eq(user));
        verify(bankHistory).logUnauthorizedOperation(isA(Withdraw.class), eq(false));
        verify(bankHistory, never()).logOperation(isA(Withdraw.class), eq(true));
    }

    @Test
    public void testInternalPayment_success() throws OperationIsNotAllowedException, SQLException {
        // given
        double amount1 = 101.00;
        double amount2 = 95.45;
        double expectedAmount1 = 1.00;
        double expectedAmount2 = 195.45;
        User user = new User();
        user.setName("Tomasz");
        Account account1 = new Account();
        account1.setAmmount(amount1);
        account1.setId(1);
        Account account2 = new Account();
        account2.setAmmount(amount2);
        account2.setId(2);
        Role role = new Role();
        role.setName("User");
        user.setRole(role);
        account1.setOwner(user);
        account2.setOwner(user);
        given(dao.findAccountById(eq(account1.getId()))).willReturn(account1);
        given(dao.findAccountById(eq(account2.getId()))).willReturn(account2);
        given(dao.updateAccountState(any())).willReturn(true);

        // when
        boolean result = accountManager.internalPayment(user, 100.00, "", account1.getId(), account2.getId());

        // then
        assertTrue(result);
        assertEquals(expectedAmount1, account1.getAmmount());
        assertEquals(expectedAmount2, account2.getAmmount());
        verify(bankHistory, never()).logLoginFailure(any(), any());
        verify(dao, times(2)).updateAccountState(any());
        verify(bankHistory, times(2)).logOperation(any(), eq(true));
    }

    @Test
    public void testInternalPayment_wrongSource() throws OperationIsNotAllowedException, SQLException {
        // given
        double amount1 = 101.00;
        double amount2 = 95.45;

        User user = new User();
        user.setName("Tomasz");
        Account account1 = new Account();
        account1.setAmmount(amount1);
        account1.setId(1);
        Account account2 = new Account();
        account2.setAmmount(amount2);
        account2.setId(2);
        Role role = new Role();
        role.setName("User");
        user.setRole(role);
        account1.setOwner(user);
        account2.setOwner(new User());
        given(dao.findAccountById(eq(account1.getId()))).willReturn(account1);
        given(dao.findAccountById(eq(account2.getId()))).willReturn(account2);
        given(dao.updateAccountState(any())).willReturn(true);

        // when then
        Exception e = Assert.assertThrows(NullPointerException.class, () -> accountManager.internalPayment(user, 100.00, "", (new Account()).getId(), account2.getId()));
    }

    @Test
    public void testInternalPayment_wrongAmount() throws OperationIsNotAllowedException, SQLException {
        // given
        double amount1 = 101.00;
        double amount2 = 95.45;
        User user = new User();
        user.setName("Tomasz");
        Account account1 = new Account();
        account1.setAmmount(amount1);
        account1.setId(1);
        Account account2 = new Account();
        account2.setAmmount(amount2);
        account2.setId(2);
        Role role = new Role();
        role.setName("User");
        user.setRole(role);
        account1.setOwner(user);
        account2.setOwner(user);
        given(dao.findAccountById(eq(account1.getId()))).willReturn(account1);
        given(dao.findAccountById(eq(account2.getId()))).willReturn(account2);

        // when
        boolean result = accountManager.internalPayment(user, 102.00, "", account1.getId(), account2.getId());

        // then
        assertFalse(result);
        assertEquals(amount1, account1.getAmmount());
        assertEquals(amount2, account2.getAmmount());
        verify(bankHistory, never()).logLoginFailure(any(), any());
        verify(bankHistory, times(2)).logOperation(any(), eq(false));
    }

    @Test
    // BUG: Ujemna kwota zwiększa konto źródłowe
    public void testInternalPayment_wrongNegativeAmount() throws OperationIsNotAllowedException, SQLException {
        // given
        double amount1 = 101.00;
        double amount2 = 95.45;
        User user = new User();
        user.setName("Tomasz");
        Account account1 = new Account();
        account1.setAmmount(amount1);
        account1.setId(1);
        Account account2 = new Account();
        account2.setAmmount(amount2);
        account2.setId(2);
        Role role = new Role();
        role.setName("User");
        user.setRole(role);
        account1.setOwner(user);
        account2.setOwner(user);
        given(dao.findAccountById(eq(account1.getId()))).willReturn(account1);
        given(dao.findAccountById(eq(account2.getId()))).willReturn(account2);

        // when
        boolean result = accountManager.internalPayment(user, -102.00, "", account1.getId(), account2.getId());

        // then
        assertFalse(result);
        assertEquals(amount1, account1.getAmmount());
        assertEquals(amount2, account2.getAmmount());
        verify(bankHistory, never()).logLoginFailure(any(), any());
        verify(bankHistory, times(2)).logOperation(any(), eq(false));
    }

    @Test
    // BUG: Użytkownik nie powininien wykonywać operacji na obcym koncie
    public void testInternalPayment_notAuthorized() throws OperationIsNotAllowedException, SQLException {
        // given
        double amount1 = 101.00;
        double amount2 = 95.45;
        User user = new User();
        user.setName("Tomasz");
        user.setId(1);
        User user2 = new User();
        user2.setName("Adam");
        user2.setId(2);
        Account account1 = new Account();
        account1.setAmmount(amount1);
        account1.setId(1);
        account1.setOwner(user);
        Account account2 = new Account();
        account2.setAmmount(amount2);
        account2.setId(2);
        account2.setOwner(user2);
        Role role = new Role();
        role.setName("User");
        user.setRole(role);
        user2.setRole(role);
        account1.setOwner(user);
        account2.setOwner(user);
        given(dao.findAccountById(eq(account1.getId()))).willReturn(account1);
        given(dao.findAccountById(eq(account2.getId()))).willReturn(account2);

        // when
        boolean result = accountManager.internalPayment(user2, 100.00, "", account1.getId(), account2.getId());

        // then
        assertFalse(result);
        assertEquals(amount1, account1.getAmmount());
        assertEquals(amount2, account2.getAmmount());
        verify(bankHistory, never()).logLoginFailure(any(), any());
        verify(bankHistory, times(2)).logOperation(any(), eq(false));
    }

    @Test
    public void testInternalPayment_notAllowed() throws OperationIsNotAllowedException, SQLException {
        // given
        double amount1 = 101.00;
        double amount2 = 95.45;
        User user = new User();
        user.setName("Tomasz");
        user.setId(1);
        User user2 = new User();
        user2.setName("Adam");
        user2.setId(2);
        Account account1 = new Account();
        account1.setAmmount(amount1);
        account1.setId(1);
        account1.setOwner(user);
        Account account2 = new Account();
        account2.setAmmount(amount2);
        account2.setId(2);
        account2.setOwner(user2);
        Role role = new Role();
        role.setName("User");
        user.setRole(role);
        user2.setRole(role);
        account1.setOwner(user);
        account2.setOwner(user);
        given(dao.findAccountById(eq(account1.getId()))).willReturn(account1);
        given(dao.findAccountById(eq(account2.getId()))).willReturn(account2);
        given(dao.updateAccountState(any())).willReturn(true);
        doReturn(false).when(authenticationManager).canInvokeOperation(isA(Withdraw.class), isA(User.class));
        doNothing().when(bankHistory).logUnauthorizedOperation(isA(Withdraw.class), anyBoolean());

        // when then
        Exception e = Assert.assertThrows(OperationIsNotAllowedException.class, () -> accountManager.internalPayment(user2, 100.00, "", account1.getId(), account2.getId()));

        // then
        assertEquals("Unauthorized operation", e.getMessage());
    }

    public void testBuildBank() {
    }

    @Test
    public void testLogIn_success() throws SQLException, UserUnnkownOrBadPasswordException {
        // given
        String username = "patryk";
        String password = "password";
        User user = new User();
        doReturn(user).when(authenticationManager).logIn(any(), any());

        // when
        boolean result = accountManager.logIn(username, password.toCharArray());

        // then
        assertTrue(result);
    }

    @Test
    public void testLogOut_success() throws SQLException {
        // given
        User user = new User();

        // when
        boolean result = accountManager.logOut(user);

        // then
        assertTrue(result);
        assertNull(accountManager.loggedUser);
    }

    @Test
    public void testLogOut_fail() throws SQLException {
        // given
        User user = new User();
        accountManager.loggedUser = user;
        doReturn(false).when(authenticationManager).logOut(user);

        // when
        boolean result = accountManager.logOut(user);

        // then
        assertFalse(result);
        assertEquals(user, accountManager.loggedUser);
    }

    @Test
    public void testLogOut_sqlError() throws SQLException {
        // given
        User user = new User();
        doThrow(SQLException.class).when(authenticationManager).logOut(user);

        // when then
        Assert.assertThrows(SQLException.class, () -> accountManager.logOut(user));
    }

    @Test
    public void testGetLoggedUser() {
        // given
        User user = new User();
        accountManager.loggedUser = user;

        // when
        User loggedUser = accountManager.getLoggedUser();

        // then
        assertEquals(loggedUser, user);

    }
}