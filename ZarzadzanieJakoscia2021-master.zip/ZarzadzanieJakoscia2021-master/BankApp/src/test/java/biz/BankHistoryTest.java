package biz;

import db.dao.DAO;
import junit.framework.TestCase;
import model.Account;
import model.Operation;
import model.User;
import model.operations.LogIn;
import org.apache.commons.lang3.NotImplementedException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.sql.SQLException;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class BankHistoryTest extends TestCase {

    @Mock
    DAO dao;

    @InjectMocks
    @Spy
    BankHistory bankHistory;

    @Test
    public void testLogLoginSuccess() throws SQLException {
        // given
        User user = new User();
        Operation operation = new LogIn(user, "desc");
        Boolean success = true;

        // when
        bankHistory.logLoginSuccess(user);

        // then
        verify(dao).logOperation(isA(Operation.class), eq(success));
    }

    @Test
    public void testLogLoginFailure() throws SQLException {
        // given
        User user = new User();
        Operation operation = new LogIn(user, "desc");
        Boolean success = false;

        // when
        bankHistory.logLoginFailure(user, "info");

        // then
        verify(dao).logOperation(isA(Operation.class), eq(success));
    }

    @Test
    public void testLogLogOut() throws SQLException {
        // given
        User user = new User();
        Operation operation = new LogIn(user, "desc");
        Boolean success = true;

        // when
        bankHistory.logLogOut(user);

        // then
        verify(dao).logOperation(isA(Operation.class), eq(success));
    }

    @Test(expected = NotImplementedException.class)
    public void testLogPaymentIn() {
        bankHistory.logPaymentIn(new Account(), 100.0, true);
    }

    @Test(expected = NotImplementedException.class)
    public void testLogPaymentOut() {
        bankHistory.logPaymentOut(new Account(), 100.0, true);
    }

    @Test
    public void testLogOperation() throws SQLException {
        // given
        Operation operation = new LogIn(new User(), "");
        Boolean success = true;

        // when
        bankHistory.logOperation(operation, success);

        // then
        verify(dao).logOperation(operation, success);
    }

    @Test(expected = NotImplementedException.class)
    public void testLogUnauthorizedOperation() {
        bankHistory.logUnauthorizedOperation(new LogIn(new User(), ""),  true);
    }
}