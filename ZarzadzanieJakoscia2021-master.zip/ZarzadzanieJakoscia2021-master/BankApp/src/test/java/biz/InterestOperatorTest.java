package biz;

import db.dao.DAO;
import junit.framework.TestCase;
import model.Account;
import model.User;
import model.operations.Interest;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.lang.reflect.Field;
import java.sql.SQLException;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.atMostOnce;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class InterestOperatorTest extends TestCase {
    @Mock
    DAO dao;

    @Mock
    AccountManager accountManager;

    @InjectMocks
    @Spy
    BankHistory bankHistory;

    @InjectMocks
    @Spy
    InterestOperator interestOperator;

    @Test
    public void testCountInterestForAccount_zeroAmount() throws SQLException, NoSuchFieldException, IllegalAccessException {
        // given
        User user = new User();
        user.setName("PatrykInterestOperator");
        user.setId(123);
        Account account = new Account();
        account.setAmmount(0.0);
        account.setId(1);
        account.setOwner(user);
        given(dao.findUserByName("InterestOperator")).willReturn(user);

        // when
        interestOperator.countInterestForAccount(account);

        // then
        verify(dao, atMostOnce()).findUserByName("InterestOperator");
        verify(accountManager).paymentIn(eq(user), eq(0.0), anyString(), eq(account.getId()));
        verify(dao, atMostOnce()).logOperation(isA(Interest.class), anyBoolean());
    }

    @Test
    // BUG: brak obsługi ujemnych kwot
    public void testCountInterestForAccount_standardAmount() throws SQLException, NoSuchFieldException, IllegalAccessException {
        // given
        double amount = 2345.12;
        User user = new User();
        Account account = new Account();
        account.setAmmount(amount);
        given(dao.findUserByName("InterestOperator")).willReturn(user);
        Field interestFactor = InterestOperator.class.getDeclaredField("interestFactor");
        interestFactor.setAccessible(true);
        double interestAmount = interestFactor.getDouble(interestOperator) * account.getAmmount();
        interestFactor.setAccessible(false);

        // when
        interestOperator.countInterestForAccount(account);

        // then
        verify(dao, atMostOnce()).findUserByName("InterestOperator");
        verify(accountManager).paymentIn(eq(user), eq(interestAmount), anyString(), eq(account.getId()));
        verify(dao, atMostOnce()).logOperation(isA(Interest.class), anyBoolean());
    }
}
